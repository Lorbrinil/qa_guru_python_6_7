pytest-6.2.5
=======================================

pytest 6.2.5 has just been released to PyPI.

This is a bug-fix release, being a drop-in replacement. To upgrade::

  pip install --upgrade pytest

The full changelog is available at https://docs.pytest.org/en/stable/changelog.html.

Thanks to all of the contributors to this release:

* Anthony Sottile
* Bruno Oliveira
* Brylie Christopher Oxley
* Daniel Asztalos
* Florian Bruhin
* Jason Haugen
* MapleCCC
* Michał Górny
* Miro Hrončok
* Ran Benita
* Ronny Pfannschmidt
* Sylvain Bellemare
* Thomas Güttler


Happy testing,
The pytest Development Team
